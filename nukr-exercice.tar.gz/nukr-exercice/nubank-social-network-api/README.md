Nukr - The Social Network
==================================================
The "Nukr" is a new social network by by Nu Everything S/A allowed all your users make the profile and connecteds with your friends.

## Usage
This API has the purpose to provide some resources for use by Nubank's developer team like create, edit, find and remove profile, connect two profile like friends, make a suggestion list of friends and also that somebody dont receiver the friendship request.

### Run the application locally
To run the Nukr API first downloaded the file sended by Email, should create the folder "nukr-exercice", after that follow the one of two option below.
##### Running by "run-nukr" file
1. Open the folder "nukr-exercice" and click in the "nukr-run"

##### Running by server.jar
the example commands it was based in Unix System.

1. Open the terminal and navigato to "nukr-exercice/nubank-social-network-api"
`cd nukr-exercice/nubank-social-network-api`
2. Enter the command below into the terminal
`lein ring server`

#### Run the tests
1. Open the terminal and navigato to "nukr-exercice/nubank-social-network-api"
`cd nukr-exercice/nubank-social-network-api`
2. Enter the command below into the terminal
`lein test`

#### Packaging and running as standalone jar
1. Open the terminal and navigato to "nukr-exercice/nubank-social-network-api"
`cd nukr-exercice/nubank-social-network-api`
2. Enter the command below into the terminal
`lein do clean, ring uberjar`
`java -jar target/server.jar`

## Architecture
This API was developed using:
* Java 8
* Leining 2.7.1
* Clojure 1.9.0
* Compojure-api 1.1.11
* Jetty 9.2.21

# Resources
The base URL is used for create request to API, in error case please first check if base URL is that right
Base URL: `http://localhost:3000/nukr/api/v1`

### Resource Profile
Get profiles's information like get by id, get all, search by name, add, delete and update data
#### Resource Address:
- /profiles/                    -- Get all.
- /profiles/id                  -- Get by id.
- /profiles/query?name=:name    -- Consult by query param

#### Request By ID Example:
`http://localhost:3000/nukr/api/v1/profiles/1`

#### Response By ID Example:
```sh
{
   "id" : 1
   "name": "Profile Example",
   "nickname": "profile-example",
   "birthdate": "1981-01-24",
   "genre": [:male],
   "connections-id": [1 2 3]
}
```
#### Base Attributes
| Name | Type | Description |
| ------ | ------ | ------- |
| name | Texto | Profile name |
| nickname | Texto | Profile's nickname |
| birthdate | Date | Birthdate of profile |
| genre | Text | Profile's genre  |
| connections-id | Number | List profile's connections |

### Example of Inclusion:
To include profile should use the HTTP POST verb, passed in body of request the JSON example below.
`http://localhost:3000/nukr/api/v1/profiles/`

### Example of Delete:
To delete profile should use the HTTP DELETE, passed in URL the resource ID.
`http://localhost:3000/nukr/api/v1/profiles/1`

## Complement Docs
For more datails about resources, request and response example, please access the below URL after the local server is running.

Docs Page: `http://localhost:3000/index.html`