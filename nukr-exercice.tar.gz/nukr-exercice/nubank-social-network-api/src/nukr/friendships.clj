(ns nukr.friendships)

(defn- create-connections-id
  "Create map with all profile's connections"
  [profiles]
  (let [profile (nth profiles 0)
        id (nth profiles 1)]
    (assoc profile :connections-id
                   (into #{}
                         (concat (get profile :connections-id) #{id})))))

(defn connect-profile
  "Connect two profiles with friend"
  [profile1 profile2]
  (let [profiles [[profile1 (get profile2 :id)]
                  [profile2 (get profile1 :id)]]]
    (doall (map create-connections-id profiles))))