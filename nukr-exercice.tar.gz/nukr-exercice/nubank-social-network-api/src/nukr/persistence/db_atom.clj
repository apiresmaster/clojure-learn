(ns nukr.persistence.db_atom
  (:require [nukr.domain.profile :as d]
            [ring.swagger.schema :refer [coerce!]]))

;;Persistence implementing

(defn- profile-exist?
  "Check in array-map if parameter profile name exists."
  [coll value]
  (some #(= % value) (map #(:name (second %)) coll)))

;; Define Record Profile
;;todo FIX - check passed data type of params
(defrecord ProfileDao [profiles-db id-seq]

  d/IDao

  (add!
    [_ new-profile]
    (if (profile-exist? @profiles-db (:name new-profile))
      (throw (Exception. "Profile already exist"))

      (let [id (swap! id-seq inc)
            profile (coerce! d/Profile (assoc new-profile :id id))]
        (swap! profiles-db assoc id profile)

        profile)))

  (get-by-id
    [_ id]
    (@profiles-db id))

  (get-by-name [_ name] (first (filter #(= name (:name %)) (vals @profiles-db))))

  (get-all [_] (-> profiles-db deref vals reverse))

  (update! [_ profile]
    (let [profile (coerce! d/Profile profile)]
      (swap! profiles-db assoc (:id profile) profile)
      (@profiles-db (:id profile))))

  (delete! [_ id] (swap! profiles-db dissoc id) nil))


