(ns nukr.handler
  (:require [compojure.api.sweet :refer :all]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [nukr.domain.profile :refer :all]
            [nukr.profile-service :as ps]))

;;todo search how to get the server uri
(def url-base "/nukr/api/v1")

(def app
  (api
    {:swagger
     {:ui "/"
      :spec "/swagger.json"
      :data {:info {:title "Nukr"
                    :description "Nukr is a new social media product by Nu Everything S/A"}
             :tags [{:name "api", :description "some apis"}]}}}

    (context (str url-base "/profiles") []
      :tags ["profiles"]

      (GET "/" []
        :summary "Gets all Profiles"
        :return [Profile]
        (ok (ps/get-all)))

      (POST "/" []
        :summary "Add a profile"
        :body [profile PersistProfile {:name "new profile"}]
        :responses    {200 {:schema {:message s/Str}, :description "The message was received but the data was not persisted."}
                       201 {:headers {:location s/Str}, :description "The message was received and the data persisted."}}
        (let [result (:id (ps/persist profile))]
          (case result
            -1 (ok {:message "The profile already exist"})
            (created (str "/profiles/"result)))))

      (PUT "/:id" []
        :return Profile
        :path-params [id :- Long]
        :body [profile PersistProfile]
        :summary "Updates a profile"
        (ok (ps/update! (assoc profile :id id))))

      (GET "/query" []
        :summary "Get profile by name"
        :query-params [name :- String]
        :responses    {200 {:schema Profile, :description "The message was received but the data was not persisted."}}
        404 {:schema {:reason s/Str}, :description "The profile is not found."}
        (let [result (ps/get-by-name name)]
          (if (empty? result)
            (not-found {:reason (format "Profile name %s not found " name)})
            (ok result))))

      (GET "/:id" []
        :summary "Get profile by ID"
        :path-params [id :- Long]
        :responses    {200 {:schema Profile, :description "The message was received but the data was not persisted."}}
        404 {:schema {:reason s/Str}, :description "The profile is not found."}
        (let [result (ps/get-by-id id)]
          (if (empty? result)
            (not-found {:reason (format "Profile id %s not found " id)})
            (ok result))))

      (DELETE "/:id" []
        :summary "Delete profile by ID"
        :path-params [id :- Long]
        (ok (ps/delete! id))))

    (context (str url-base "/friendships") []
      :tags ["friendships"]

      (POST "/" []
        :summary      "Connect two profiles like friends."
        :body [profile-connect NewConnection]
        :responses    {200 {:schema {:message s/Str}, :description "The message was received but the data was not persisted."}
                       201 {:headers {:location s/Str}, :description "The message was received and the data persisted."}}

        (let [result  (ps/become-friends profile-connect)]
          (if result
            (created (str "/profiles/"(:id profile-connect)))

            (ok {:message "Connection not done"})))))))

