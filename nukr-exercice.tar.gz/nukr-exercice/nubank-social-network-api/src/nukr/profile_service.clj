(ns nukr.profile-service
  (:require [nukr.domain.profile :as d]
            [nukr.persistence.db_atom :refer :all]
            [nukr.friendships :refer :all])
  (:import (nukr.persistence.db_atom ProfileDao)))

(defonce id-seq (atom 0))
(defonce profiles-db (atom (array-map)))

(def build (ProfileDao. profiles-db id-seq))


(defn persist
  [new-profile]
  (try
    (d/add! build new-profile)
    (catch Exception e
      {:id -1})))

(defn get-by-id
  [id]
  (d/get-by-id build id))

(defn get-by-name
  [name]
  (d/get-by-name build name))

(defn get-all
  []
  (d/get-all build))

(defn update!
  [profile]
  (d/update! build profile))

(defn delete!
  [id]
  (d/delete! build id))

(defn become-friends
  [profile-connection]
  (let [profiles (map get-by-id (vals profile-connection))]
    (if (some empty? profiles)
      false

      (doall (map update!
                  (connect-profile (first profiles)
                                   (second profiles)))))))