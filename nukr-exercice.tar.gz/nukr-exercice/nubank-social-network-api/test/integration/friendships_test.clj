(ns integration.friendships-test
  (:require [clojure.test :refer :all][ring.mock.request :as mock]
            [nukr.handler :refer :all]
            [java-time :as time]))

(defn add-profile-by-request-mock
  "Persist profile with request mock"
  [new-profile]
  (app (-> (mock/request :post  "/profiles/")
           (mock/json-body new-profile))))

(deftest making-friends-used-service-profile
  (testing "Test GET method to request /profiles/:id that not exist"
    (let [response-friend1 (add-profile-by-request-mock {:name "Friend3"
                                                         :nickname "friend1"
                                                         :birthdate (time/local-date 1995 01 01)
                                                         :genre #{:male}})

          response-friend2 (add-profile-by-request-mock {:name "Friend4"
                                                         :nickname "friend2"
                                                         :birthdate (time/local-date 1995 01 01)
                                                         :genre #{:male}})

          location-friend1         (val (first (:headers response-friend1)))
          location-friend2         (val (first (:headers response-friend2)))

          new-connection {:id (-> (re-find #"\d+" location-friend1)
                                  Long/parseLong)
                          :connections-id (-> (re-find #"\d+" location-friend2)
                                              Long/parseLong)}

          response-friendship (app (-> (mock/request :post (str "/friends/"))
                                       (mock/json-body new-connection)))]

      (is (= 201
             (:status response-friend1)
             (:status response-friend2)
             (:status response-friendship))))))