(ns integration.core-test
  (:require [cheshire.core :as cheshire]
            [clojure.test :refer :all]
            [nukr.handler :refer :all]
            [ring.mock.request :as mock]
            [java-time :as time]))

(defn parse-body [body]
  (cheshire/parse-string (slurp body) true))

(def PROFILE-TEST-GET-BY-ID {:name "ProfileGetByName16"
                             :nickname "profilegetbyid3"})

(def PROFILE-TEST-GET-BY-NAME {:name "ProfileGetByName4"
                               :nickname "profilegetbyname4"})

(defn add-profile-by-request-mock
  "Persist profile with request mock"
  [new-profile]
  (app (-> (mock/request :post  "/profiles/")
           (mock/json-body new-profile))))

(deftest add-new-profile

  (testing "Test POST request to /profiles/ persisting data and returns expected response"
    (let [response (add-profile-by-request-mock {:name "New Profile1"
                                                 :nickname "newprofile"
                                                 :birthdate (java-time/local-date 1995 01 01)
                                                 :genre #{:male}})]
      (is (= (:status response) 201)))))

(deftest add-same-profile

  (testing "Test POST HTTP method to /profiles/ but not persisting, return http 200
  with a body message"
    (let [profile {:name "ExistProfile"
                   :nickname "existprofile"
                   :birthdate (java-time/local-date 1995 01 01)
                   :genre #{:male}}

          response-ok (add-profile-by-request-mock profile)
          response-http-200 (add-profile-by-request-mock profile)]

      (is (= 201 (:status response-ok)))
      (is (= 200 (:status response-http-200))))))

(deftest get-profile-by-name

  (testing "Test POST request to /profiles/ persisting data and returns expected response"
    (let [response-persist (add-profile-by-request-mock
                             (merge PROFILE-TEST-GET-BY-NAME {:birthdate (java-time/local-date 1995 01 01)
                                                              :genre #{:male}}))]
      (is (= 201 (:status response-persist)))))

      (testing "Test GET request to /profiles/ return profile by name expected response"
        (let [response-get-name (app (-> (mock/request :get (str "/profiles/query?name=" (:name PROFILE-TEST-GET-BY-NAME)))))
              body     (parse-body (:body response-get-name))]

          (is (= 200 (:status response-get-name)))
          (is (= (:name PROFILE-TEST-GET-BY-NAME) (:name body))))))

(deftest get-profile-by-id

  (testing "Test POST request to /profiles/ persisting data and returns expected response"
    (let [response-persist (add-profile-by-request-mock
                             (merge PROFILE-TEST-GET-BY-ID {:birthdate (java-time/local-date 1995 01 01)
                                                            :genre #{:male}}))
          location         (val (first (:headers response-persist)))
          response-get-id (app (-> (mock/request :get (str "/profiles/" (re-find #"\d+" location)))))
          body     (parse-body (:body response-get-id))]

      (is (= 201 (:status response-persist)))
      (is (= (:name PROFILE-TEST-GET-BY-ID) (:name body))))))

(deftest profile-get-id-not-found
  (testing "Test GET method to request /profiles/:id that not exist"
    (let [response (app (-> (mock/request :get (str "/profiles/-1"))))
          body     (parse-body (:body response))]

    (is (= 404 (:status response)))
    (is (empty? (:name body))))))