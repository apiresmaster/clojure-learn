(ns unit.domain-test
  (:require [clojure.test :refer :all]
            [schema.core :as s]
            [nukr.domain.profile :as domain]
            [nukr.profile-service :as service]
            [java-time :as time])
  (:import (nukr.persistence.db_atom ProfileDao)))

(def expected-new-profile {:name "Profile1"
                           :nickname "profile1"
                           :birthdate (java-time/local-date 1995 01 01)
                           :genre #{:male}})

(deftest add-new-profile

  (testing "Test profile include with properties name, nickname birthdate and genre return nilable"
    (let [id-seq (atom 0)
          profiles-db (atom (array-map))
          profile-db-mock (ProfileDao. profiles-db id-seq)]
      (is (s/validate domain/PersistProfile expected-new-profile))
      (is (domain/add! profile-db-mock expected-new-profile)))))

(deftest get-by-name

  (testing "Test get by name profile"
    (is (s/validate domain/PersistProfile expected-new-profile))
    (is (service/persist expected-new-profile))
    (is (= "Profile1" (:name (service/get-by-name (:name expected-new-profile)))))))