(ns unit.friendships-test
  (:require [clojure.test :refer :all]
            [schema.core :as s]
            [nukr.domain.profile :as d]
            [nukr.friendships :refer :all]
            [ring.mock.request :as mock]
            [nukr.handler :refer :all]
            [cheshire.core :as cheshire]
            [java-time :as time]))

(deftest making-friends-two-profile-friendless

  (testing "Connect two profiles that there not have friends."
    (let [expected-profile1 1
          expected-profile2 2
          profile1 {:id expected-profile1
                    :name "Profile1"
                    :nickname "profile1"
                    :birthdate "19800101"
                    :genre #{:male}}
          profile2 {:id expected-profile2
                    :name "Profile2"
                    :nickname "profile2"
                    :birthdate "19800101"
                    :genre #{:male}}
          profiles-connecteds (connect-profile profile1 profile2)]

      (is (contains?
            (:connections-id (first profiles-connecteds)) expected-profile2))
      (is (contains?
            (:connections-id (second profiles-connecteds)) expected-profile1)))))

(deftest making-friends-two-profile-with-friends

  (testing "Connect two profiles that have some friends."
    (let [expected-profile1 5
          expected-profile2 4
          profile1 {:id 4
                    :name "Profile3"
                    :nickname "profile1"
                    :birthdate "19800101"
                    :genre #{:male}
                    :connections-id #{1 2 3}}
          profile2 {:id 5
                    :name "Profile4"
                    :nickname "profile2"
                    :birthdate "19800101"
                    :genre #{:male}
                    :connections-id #{1 2 3}}
          profiles-connecteds (connect-profile profile1 profile2)]

      (is (contains? 
            (:connections-id (first profiles-connecteds)) expected-profile1))
      (is (contains? 
            (:connections-id (second profiles-connecteds)) expected-profile2)))))