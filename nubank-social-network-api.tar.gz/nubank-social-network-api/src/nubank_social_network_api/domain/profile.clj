(ns nubank-social-network-api.domain.profile
  (:require [schema.core :as s]
            [ring.swagger.schema :refer [coerce!]]))

;;Domain definition

(def Genre (s/enum :male :female))

(s/defschema ProfileBase {:id    Long
                          :name  String
                          :nickname String
                          :birthdate java.time.LocalDate
                          :genre #{Genre}})

(s/defschema Profile (assoc ProfileBase (s/optional-key? :connections-id) #{Long}))

(s/defschema PersistProfile (dissoc ProfileBase :id))

(s/defschema NewConnection {:id Long
                            :connections-id Long})


;;Interface definition

(defprotocol IDao
  "Defines the functions that should be implemented to work with Profile domain."
  (add! [this new-profile])
  (get-by-id [this id])
  (get-by-name [this name])
  (get-all [this])
  (update! [this profile])
  (delete! [this id]))