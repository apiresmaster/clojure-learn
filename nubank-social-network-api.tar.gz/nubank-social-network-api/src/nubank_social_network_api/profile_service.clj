(ns nubank-social-network-api.profile-service
  (:require [nubank-social-network-api.domain.profile :as d]
            [nubank-social-network-api.persistence.profile-db-memory :refer :all]
            [nubank-social-network-api.friendships :refer :all])
  (:import (nubank_social_network_api.persistence.profile_db_memory ProfileDao)))

(defonce id-seq (atom 0))
(defonce profiles-db (atom (array-map)))

(def build (ProfileDao. profiles-db id-seq))


(defn persist
  [new-profile]
  (try
    (d/add! build new-profile)
    (catch Exception e
      {:id -1})))

(defn get-by-id
  [id]
  (d/get-by-id build id))

(defn get-by-name
  [name]
  (d/get-by-name build name))

(defn get-all
  []
  (d/get-all build))

(defn update!
  [profile]
  (d/update! build profile))

(defn delete!
  [id]
  (d/delete! build id))

(defn become-friends
  [profile-connection]
  (let [profiles (map get-by-id (vals profile-connection))]
    (if (some empty? profiles)
      false

      (do
        (map update!
             (connect-profile (first profiles)
                              (second profiles)))
        true))))