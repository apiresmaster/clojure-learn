(ns nubank-social-network-api.handler
  (:require [compojure.api.sweet :refer :all]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [nubank-social-network-api.domain.profile :refer :all]
            [nubank-social-network-api.profile-service :as ps]))

(def app
  (api
    {:swagger
     {:ui "/"
      :spec "/swagger.json"
      :data {:info {:title "Nubank-social-network-api"
                    :description "Compojure Api example"}
             :tags [{:name "api", :description "some apis"}]}}}

    (context "/profiles" []
      :tags ["profiles"]

      (GET "/" []
        :summary "Gets all Profiles"
        :return [Profile]
        (ok (ps/get-all)))

      (POST "/" []
        :body [profile PersistProfile {:name "new profile"}]
        :responses    {200 {:schema {:message s/Str}, :description "Message with status of response"}
                       201 {:headers {:location s/Str}}}
        :summary "Adds a profile"
        (let [result (:id (ps/persist profile))]
          (case result
            -1 (ok {:message "The profile already exist"})
            (created (str "/profiles/"result)))))

      (PUT "/:id" []
        :return Profile
        :path-params [id :- Long]
        :body [profile PersistProfile]
        :summary "Updates a profile"
        (ok (ps/update! (assoc profile :id id))))

      (GET "/query" []
        :summary "Gets a profile by name"
        :query-params [name :- String]
        :responses    {200 {:schema Profile, :description "Message with status of response"}}
        404 {:schema {:reason s/Str}, :description "lost?"}
        (let [result (ps/get-by-name name)]
          (if (empty? result)
            (not-found {:reason (format "Profile name %s not found " name)})
            (ok result))))

      (GET "/:id" []
        :summary "Gets profile by id"
        :path-params [id :- Long]
        :responses    {200 {:schema Profile, :description "happy path"}}
        404 {:schema {:reason s/Str}, :description "lost?"}
        (let [result (ps/get-by-id id)]
          (if (empty? result)
            (not-found {:reason (format "Profile id %s not found " id)})
            (ok result))))

      (DELETE "/:id" []
        :summary "Deletes a Profile"
        :path-params [id :- Long]
        (ok (ps/delete! id))))

    (context "/friends" []
      :tags ["friends"]

      (POST "/" []
        :summary      "multiple returns models"
        :body [profile-connect NewConnection]
        :responses    {200 {:schema {:message s/Str}, :description "happy path"}
                       201 {:headers {:location s/Str}}}
        (let [result  (ps/become-friends profile-connect)]
          (if result
            (ok {:message "Connection not done"})
            (created (str "/profiles/"(:id profile-connect)))))))))

