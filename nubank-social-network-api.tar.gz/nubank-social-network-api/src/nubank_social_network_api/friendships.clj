(ns nubank-social-network-api.friendships)

(defn- create-connections-id
  "Create map with all profile's connections"
  [profile id]
  (assoc profile :connections-id (into #{} (concat (get profile :connections-id) #{id}))))

(defn connect-profile
  "Connect two profiles with friend"
  [profile1 profile2]
  (map #(create-connections-id (nth % 0) (nth % 1)) [[profile1 (get profile2 :id)]
                                                     [profile2 (get profile1 :id)]]))