(ns nubank-social-network-api.friendships-test
  (:require [clojure.test :refer :all]
            [schema.core :as s]
            [nubank-social-network-api.domain.profile :as d]
            [nubank-social-network-api.friendships :refer :all]
            [ring.mock.request :as mock]
            [nubank-social-network-api.handler :refer :all]
            [cheshire.core :as cheshire]))

(defn parse-body [body]
  (cheshire/parse-string (slurp body) true))

(deftest making-friends-two-profile-friendless

  (testing "Connect two profiles that there not have friends."
    (let [id-profile1 1
          id-profile2 2
          profile1 {:id id-profile1
                    :name "Profile1"
                    :nickname "profile1"
                    :birthdate "19800101"
                    :genre #{:male}}
          profile2 {:id id-profile2
                    :name "Profile2"
                    :nickname "profile2"
                    :birthdate "19800101"
                    :genre #{:male}}
          connections-profile1 (get profile1 :connections-id)
          connections-profile2 (get profile2 :connections-id)]

      (is (contains? (get (assoc profile1 :connections-id #{2}) :connections-id) id-profile2))
      (is (contains? (get (assoc profile2 :connections-id #{1}) :connections-id) id-profile1)))))

(deftest making-friends-two-profile-with-friends

  (testing "Connect two profiles that have some friends."
    (let [expected-profile1 5
          expected-profile2 4
          profile1 {:id 4
                    :name "Profile1"
                    :nickname "profile1"
                    :birthdate "19800101"
                    :genre #{:male}
                    :connections-id #{1 2 3}}
          profile2 {:id 5
                    :name "Profile2"
                    :nickname "profile2"
                    :birthdate "19800101"
                    :genre #{:male}
                    :connections-id #{1 2 3}}
          profiles-connecteds (connect-profile profile1 profile2)]

      (is (contains? 
            (:connections-id (first profiles-connecteds)) expected-profile1))
      (is (contains? 
            (:connections-id (second profiles-connecteds)) expected-profile2)))))

(deftest making-friends-used-service-profile
  (testing "Test GET method to request /profiles/:id that not exist"
    (let [new-connection {:id 1 :connections-id 2}
          response (app (-> (mock/request :post (str "/friends/"))
                            (mock/json-body new-connection)))
          body     (parse-body (:body response))]

      (is (= 404 (:status response)))
      (is (empty? (:name body))))))