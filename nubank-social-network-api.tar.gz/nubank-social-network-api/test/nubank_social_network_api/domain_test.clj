(ns nubank-social-network-api.domain-test
  (:require [clojure.test :refer :all]
            [schema.core :as s]
            [nubank-social-network-api.domain.profile :as d]
            [nubank-social-network-api.profile-service :as service]
            [nubank-social-network-api.persistence.profile-db-memory :refer :all])
  (:import (nubank_social_network_api.persistence.profile_db_memory ProfileDao)))

(def expected-new-profile {:name "Profile1"
                           :nickname "profile1"
                           :birthdate "19800101"
                           :genre #{:male}})

(deftest add-new-profile

  (testing "Test profile include with properties name, nickname birthdate and genre return nilable"
    (let [id-seq (atom 0)
          profiles-db (atom (array-map))
          profile-db-mock (ProfileDao. profiles-db id-seq)]
      (is (s/validate d/PersistProfile expected-new-profile))
      (is (d/add! profile-db-mock expected-new-profile)))))

(deftest get-by-name

  (testing "Test get by name profile"
    (let [id-seq (atom 0)
          profiles-db (atom (array-map))
          profile-db-mock (ProfileDao. profiles-db id-seq)]
      (is (s/validate d/PersistProfile expected-new-profile))
      (is (service/persist expected-new-profile))
      (is (= "Profile1" (:name (service/get-by-name (:name expected-new-profile))))))))